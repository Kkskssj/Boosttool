<h1 align="center">
  
</h1>

<h2 align="center">
  Remember This Boost Tool ONLY allows you to boost servers if you have nitro tokens!
</h2>

![image](https://i.ibb.co/cN6QwD3/ima3434ge.webp) 

<h3 align="center">
Please ⭐ This Repo If You Like It!
</h3>
<h3 align="center">
<a href="https://guns.lol/solve">CONTACT ME HERE</a>
</h3>



## Setup
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

Download Python here: [DOWNLOAD](https://www.python.org/downloads/) 

(Python v3.9 or higher is recommended)



### Requirements:
- [x] - **Windows 10 / 11**
- [x] - **Python** [DOWNLOAD](https://www.python.org/ftp/python/3.10.5/python-3.10.5-amd64.exe)
- [x] - **Capmonster key** 
- [ ] - **Your own proxies (I recommend paid proxies but free works)**
